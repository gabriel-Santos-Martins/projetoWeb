package main.java.security;

import org.mindrot.jbcrypt.BCrypt;

public class AuthManager {

    // Simulação de usuário cadastrado
    private static final String USERNAME = "admin";
    private static final String HASHED_PASSWORD = BCrypt.hashpw("123456", BCrypt.gensalt());

    // Verifica se login é válido
    public static boolean validate(String username, String password) {
        return username.equals(USERNAME) && BCrypt.checkpw(password, HASHED_PASSWORD);
    }
}
