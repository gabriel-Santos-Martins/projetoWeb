package main.java.servlet;

import security.AuthManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (AuthManager.validate(username, password)) {
            HttpSession session = request.getSession();
            session.setAttribute("usuarioLogado", username);
            response.sendRedirect("home.jsp");
        } else {
            request.setAttribute("erro", "Usuário ou senha inválidos.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
